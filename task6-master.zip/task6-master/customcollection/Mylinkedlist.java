
public class Mylinkedlist {

		public static void main(String args[])
		{
		Linkedlist a=new Linkedlist();
		a.initiallist();
		a.print();
		a.selection();
		}
	}

